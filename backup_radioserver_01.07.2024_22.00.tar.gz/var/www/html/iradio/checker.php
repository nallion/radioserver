<?php
echo shell_exec("cat /var/www/html/iradio/radios.txt | { awk -F '%' '{print  \"http://\"$2 $3}");
