while true
 do
 ffmpeg -re -i https://stream-161.zeno.fm/x7mve2vt01zuv?zs=D4nKO5-7SsK2FZAsvumh2w -acodec libmp3lame -ar 32000 -ab 40k -ac 1 -af "equalizer=f=13000:width_type=h:width=4000:g=+40" -vn -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/jx5SCJUd27.mp3
 sleep 300
 done
