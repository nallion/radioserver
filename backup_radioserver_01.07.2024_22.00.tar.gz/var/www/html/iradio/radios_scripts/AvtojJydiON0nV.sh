while true
 do
 ffmpeg -re -i http://ic7.101.ru:8000/v3_1 -acodec libmp3lame -ar 32000 -ab 40k -ac 1 -af "equalizer=f=13000:width_type=h:width=4000:g=+40" -vn -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/jJydiON0nV.mp3
 sleep 300
 done
