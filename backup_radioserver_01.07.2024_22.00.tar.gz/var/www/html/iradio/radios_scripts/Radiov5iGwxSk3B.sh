while true
 do
 ffmpeg -re -i http://playerservices.streamtheworld.com/api/livestream-redirect/DISNEY_ARG_BA.mp3 -acodec libmp3lame -ar 32000 -ab 40k -ac 1 -af "equalizer=f=13000:width_type=h:width=4000:g=+40" -vn -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/v5iGwxSk3B.mp3
 sleep 300
 done
