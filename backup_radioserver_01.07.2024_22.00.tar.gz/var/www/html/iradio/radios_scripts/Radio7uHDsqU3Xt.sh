while true
 do
 ffmpeg -re -i http://18.220.84.192:8484 -acodec libmp3lame -ar 32000 -ab 40k -ac 1 -af "equalizer=f=13000:width_type=h:width=4000:g=+40" -vn -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/7uHDsqU3Xt.mp3
 sleep 300
 done
