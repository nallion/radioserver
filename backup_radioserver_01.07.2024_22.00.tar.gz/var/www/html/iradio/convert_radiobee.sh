#!/bin/bash
cat /var/www/html/iradio/radios.txt | awk -F '%' '{print " "$1"\||\http://"$2 $3"""||40||0||0<br>"}' | tr -d '\r\n' > /var/www/html/iradio/radiobee.txt
