while true
 do
 ffmpeg -re -i http://listen.42fm.ru:8000/stealkill-320 -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/316YjxVmlw.mp3
 sleep 300
 done
