while true
 do
 ffmpeg -re -i https://14843.live.streamtheworld.com/ROCKANDPOP.mp3 -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/ktOsQrME1d.mp3
 sleep 300
 done
