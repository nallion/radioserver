#!/bin/bash
while true
do
ffmpeg -re -i http://stream-148.zeno.fm/0ghtfp8ztm0uv?zs=fcfkH5A1Ssi4PNvrmTgXmg -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/kkum.mp3
sleep 300
done
