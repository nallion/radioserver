#!/bin/bash
while true
do
ffmpeg -re -i https://nashe1.hostingradio.ru:18000/nashe20-128.mp3 -acodec libmp3lame -ar 32000 -ab 40k -ac 1 -af "equalizer=f=13000:width_type=h:width=4000:g=+40" -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/nashe2.mp3
sleep 2
done
