#!/bin/bash
while true
do
ffmpeg -re -i https://pub0102.101.ru:8443/stream/pro/aac/64/43 -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/rurap.mp3
sleep 300
done
