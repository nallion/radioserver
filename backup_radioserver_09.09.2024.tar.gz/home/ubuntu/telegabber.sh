#!/bin/bash
while true
do
cd /usr/src/telegabber && ./telegabber
sleep 2
done
