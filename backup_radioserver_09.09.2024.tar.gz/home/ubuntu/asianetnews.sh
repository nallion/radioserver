#!/bin/bash
while true
do
ffmpeg -re -i https://vidcdn.vidgyor.com/asianet-origin/audioonly/chunks.m3u8 -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/asianetnews.mp3
sleep 300
done
