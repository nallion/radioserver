#!/bin/bash
cat /var/www/html/iradio/radios.txt | awk -F '%' '{print "http://"$2 $3""}' > /tmp/1.txt
while read LINE; do
    curl -s -w "%{http_code}" "$LINE"
    echo " $LINE"
done < /tmp/1.txt
