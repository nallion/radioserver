while true
 do
 ffmpeg -re -i http://stream-143.zeno.fm/0zkr7x8ztm0uv?zs=WTPQx8TiQXSo11XU0iyTAQ -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -vn -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/iQhgqC6u5c.mp3
 sleep 300
 done
