while true
 do
 ffmpeg -re -i https://yuppmedtaorire.akamaized.net/v1/master/a0d007312bfd99c47f76b77ae26b1ccdaae76cb1/24_nim_https/110322/channel24/playlist.m3u8 -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -vn -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/dDnz3sIgf6.mp3
 sleep 300
 done
