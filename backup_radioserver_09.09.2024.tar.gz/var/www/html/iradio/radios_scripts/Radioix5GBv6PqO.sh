while true
 do
 ffmpeg -re -i http://18.220.84.192:8484 -acodec libmp3lame -ar 32000 -ab 40k -ac 1  -vn -bufsize 10240k -content_type 'audio/mpeg' -legacy_icecast 1 icecast://source:lfflu41b@127.0.0.1:8000/ix5GBv6PqO.mp3
 sleep 300
 done
