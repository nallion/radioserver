<?php
echo exec("free -m | sed -n '2p' | awk -F ' ' '{print \"Ram used: \"$3 \" / \" \"Total:\" \" \" $2}'");
echo "&nbsp;";
echo exec("top -b -n 1 | grep %Cpu\"(s)\" | awk -F ' ' '{print \"Cpu usage: \" $2 \"%\"}'");
echo "&nbsp;";
echo exec("wc radios.txt | awk '{ print \"Number of transcoded radios: \" $1 -7 }'");
echo "&nbsp";
echo "<br>";
echo "Listeners:";
echo "<b>";
echo exec("curl http://admin:lfflu41b@tg-gw.com:8000/admin/stats.xml | grep -oP '(?<=\<listeners>).*?(?=\</listeners\>)' | head -n 1");
echo "</b>";
?>
