<?php
echo exec("free -m | sed -n '2p' | awk -F ' ' '{print \"Ram used: \"$3 \" / \" \"Total:\" \" \" $2}'");
echo "&nbsp;";
echo exec("top -b -n 1 | grep %Cpu\"(s)\" | awk -F ' ' '{print \"Cpu usage: \" $2 \"%\"}'");
echo "&nbsp;";
echo exec("wc radios.txt | awk '{ print \"Number of transcoded radios: \" $1 -7 }'")
?>
